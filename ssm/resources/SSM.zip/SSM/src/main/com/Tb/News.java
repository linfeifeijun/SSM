package Tb;
import java.util.Date;

public class News {
    private  int id;
    private  String title;
    private  String content;
    private  String author;
    private  Date date;
//id
    public int getId() {
        return id;
    }
    public void setId(int id) { this.id = id; }
//标题
    public String getTitle() { return title; }
    public void setTitle(String title) {
        this.title = title;
    }
//内容
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
//作者
    public String getAuthor() {
        return author;
    }
    public void setAuthor(String author) {
        this.author = author;
    }
//riqi
    public Date getDate() { return date; }
    public void setDate(Date Date) { this.date = date; }




}
